import cmdline.Cmd;

public class SnakeCmd
{
	/** Método principal */
	public static void main(String[] args)
	{
		new Cmd();
	}
}