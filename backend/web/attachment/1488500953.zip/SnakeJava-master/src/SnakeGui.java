import gui.GuiFrame;

public class SnakeGui
{
	/** Método principal */
	public static void main(String[] args)
	{
		new GuiFrame();
	}
}